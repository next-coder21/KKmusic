import React, { useEffect, useState } from 'react';
import { FiTrash2, FiPlus, FiMusic } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { AdminTableSkeleton } from '../../components/common/Skeletons';
import { songDefaults } from '../../utils/songUtils';

const AdminSongs = ({ api }) => {
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [newSong, setNewSong] = useState({ title: '', audiourl: '', cover_url: '', duration_seconds: '', artist_id: '', album_id: '' });

  const fetchSongs = async () => {
    try {
      const { data } = await api.get('/songs');
      setSongs(data);
    } catch (err) {
      toast.error("Failed to load songs");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchSongs(); }, [api]);

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this song completely?")) return;
    try {
      await api.delete(`/songs/${id}`);
      setSongs(songs.filter(s => s.id !== id));
      toast.success("Song deleted");
    } catch (err) {
      toast.error("Deletion failed");
    }
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    try {
      await api.post('/songs', { ...newSong, duration_seconds: parseInt(newSong.duration_seconds) || 0 });
      toast.success("Song added successfully");
      setShowModal(false);
      fetchSongs();
    } catch (err) {
      toast.error("Failed to add song");
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-black tracking-tight">Manage Songs</h1>
        <button onClick={() => setShowModal(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white px-5 py-2.5 rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-cyan-900/50">
          <FiPlus /> Add Song
        </button>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-950/50 text-gray-400 text-sm uppercase tracking-wider border-b border-gray-800">
                <th className="p-4 font-semibold">Track</th>
                <th className="p-4 font-semibold">Artist</th>
                <th className="p-4 font-semibold">Album</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                <tr><td colSpan="4"><AdminTableSkeleton cols={4} rows={10} /></td></tr>
              ) : songs.length === 0 ? (
                <tr><td colSpan="4" className="p-8 text-center text-gray-500">No songs found in catalog.</td></tr>
              ) : (
                songs.map(rawSong => {
                  const song = songDefaults(rawSong);
                  return (
                    <tr key={song.id} className="hover:bg-gray-800/50 transition-colors">
                      <td className="p-4 flex items-center gap-4">
                        <div className="w-10 h-10 rounded bg-gray-800 flex-shrink-0 overflow-hidden">
                          <img src={song.cover_url} alt="cover" className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <p className="font-bold text-white">{song.title}</p>
                          <p className="text-xs text-gray-500">{Math.floor(song.duration_seconds/60)}:{(song.duration_seconds%60).toString().padStart(2,'0')}</p>
                        </div>
                      </td>
                      <td className="p-4 text-gray-300">{song.artist_name || 'Unknown'}</td>
                      <td className="p-4 text-gray-300">{song.album_title || 'Single'}</td>
                      <td className="p-4 text-right">
                        <button onClick={() => handleDelete(song.id)} className="p-2 text-gray-500 hover:text-red-400 hover:bg-gray-800 rounded-lg transition-colors" title="Delete">
                          <FiTrash2 />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">Add New Song</h2>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Title *</label>
                <input required type="text" value={newSong.title} onChange={e=>setNewSong({...newSong, title: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="Song Title" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Audio URL (Stream/Drive) *</label>
                <input required type="text" value={newSong.audiourl} onChange={e=>setNewSong({...newSong, audiourl: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="https://..." />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Cover Image URL</label>
                  <input type="text" value={newSong.cover_url} onChange={e=>setNewSong({...newSong, cover_url: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="https://..." />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Duration (Secs)</label>
                  <input type="number" value={newSong.duration_seconds} onChange={e=>setNewSong({...newSong, duration_seconds: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="215" />
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-gray-800">
                <button type="button" onClick={() => setShowModal(false)} className="px-5 py-2.5 text-gray-400 hover:text-white font-semibold">Cancel</button>
                <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-2.5 rounded-xl font-bold transition-colors">Save Song</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSongs;
