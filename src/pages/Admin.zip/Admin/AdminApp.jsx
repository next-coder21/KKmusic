import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate, useNavigate, useLocation, Link } from "react-router-dom";
import { FiGrid, FiMusic, FiUsers, FiMic, FiDisc, FiAlertTriangle, FiLogOut, FiMenu, FiX, FiLayers } from "react-icons/fi";
import axios from "axios";
import ApiService from "../../services/ApiService";
import AdminLogin from "./AdminLogin";
import AdminDashboard from "./AdminDashboard";
import AdminSongs from "./AdminSongs";
import AdminAnnouncements from "./AdminAnnouncements";
import AdminArtists from "./AdminArtists";
import AdminAlbums from "./AdminAlbums";
import AdminUsers from "./AdminUsers";
import AdminReports from "./AdminReports";

// Admin API Base URL
const adminApi = axios.create({
  baseURL: `${ApiService.getBaseUrl().replace('/auth', '/admin')}`,
  withCredentials: true
});

const AdminSidebar = ({ onLogout, api }) => {
  const location = useLocation();
  const [scheduledCount, setScheduledCount] = useState(0);

  useEffect(() => {
    const fetchScheduled = async () => {
      try {
        const { data } = await api.get('/announcements?status=scheduled');
        setScheduledCount(data.total || 0);
      } catch (e) {
        console.error("Failed to fetch scheduled count");
      }
    };
    fetchScheduled();
    const interval = setInterval(fetchScheduled, 60000); // Poll every minute
    return () => clearInterval(interval);
  }, [api]);

  const menuItems = [
    { name: "Dashboard", icon: FiGrid, path: "/admin" },
    { name: "Announcements", icon: FiLayers, path: "/admin/announcements", badge: scheduledCount },
    { name: "Songs", icon: FiMusic, path: "/admin/songs" },
    { name: "Artists", icon: FiMic, path: "/admin/artists" },
    { name: "Albums", icon: FiDisc, path: "/admin/albums" },
    { name: "Users", icon: FiUsers, path: "/admin/users" },
    { name: "Reports", icon: FiAlertTriangle, path: "/admin/reports" }
  ];

  return (
    <div className="w-64 bg-gray-900 border-r border-gray-800 text-white flex flex-col h-screen fixed top-0 left-0 z-50">
      <div className="p-6">
        <h2 className="text-2xl font-black text-cyan-400 tracking-wider">KK ADMIN</h2>
        <p className="text-gray-400 text-xs mt-1 uppercase font-bold tracking-widest">Control Panel</p>
      </div>
      <div className="flex-1 px-4 space-y-2 mt-4 overflow-y-auto">
        {menuItems.map(item => (
          <Link 
            key={item.path} 
            to={item.path}
            className={`flex items-center justify-between px-4 py-3 rounded-lg font-medium transition-all ${
              location.pathname === item.path || (item.path !== '/admin' && location.pathname.startsWith(item.path))
                ? 'bg-cyan-600 text-white shadow-lg' 
                : 'text-gray-400 hover:text-white hover:bg-gray-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <item.icon size={18} />
              {item.name}
            </div>
            {item.badge > 0 && (
              <span className="bg-amber-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded-md shadow-sm animate-pulse">
                {item.badge}
              </span>
            )}
          </Link>
        ))}
      </div>
      <div className="p-4 border-t border-gray-800">
        <button onClick={onLogout} className="flex items-center gap-3 w-full px-4 py-3 text-red-400 hover:bg-red-500/10 hover:text-red-300 rounded-lg transition-colors font-semibold">
          <FiLogOut size={18} />
          Sign Out
        </button>
      </div>
    </div>
  );
};

const AdminApp = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await adminApi.get('/check-auth');
        setIsAdmin(true);
      } catch (err) {
        setIsAdmin(false);
        if (location.pathname !== '/admin/login') {
          navigate('/admin/login');
        }
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, [navigate, location.pathname]);

  const handleLogout = async () => {
    try {
      await adminApi.post('/logout');
      setIsAdmin(false);
      navigate('/admin/login');
    } catch (e) {
      console.error("Logout failed");
    }
  };

  if (loading) return <div className="min-h-screen bg-gray-950 flex items-center justify-center text-cyan-400 font-bold text-xl">Loading Admin...</div>;

  if (!isAdmin) {
    return (
      <Routes>
        <Route path="/login" element={<AdminLogin onLogin={() => { setIsAdmin(true); navigate('/admin'); }} />} />
        <Route path="*" element={<Navigate to="/admin/login" replace />} />
      </Routes>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white flex font-sans">
      <AdminSidebar onLogout={handleLogout} api={adminApi} />
      <div className="flex-1 ml-64 p-8 overflow-y-auto">
        <Routes>
          <Route path="/" element={<AdminDashboard api={adminApi} />} />
          <Route path="/announcements" element={<AdminAnnouncements api={adminApi} />} />
          <Route path="/songs" element={<AdminSongs api={adminApi} />} />
          <Route path="/artists" element={<AdminArtists api={adminApi} />} />
          <Route path="/albums" element={<AdminAlbums api={adminApi} />} />
          <Route path="/users" element={<AdminUsers api={adminApi} />} />
          <Route path="/reports" element={<AdminReports api={adminApi} />} />
          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Routes>
      </div>
    </div>
  );
};

export default AdminApp;
