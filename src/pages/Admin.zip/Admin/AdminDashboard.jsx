import React, { useEffect, useState } from 'react';
import { FiUsers, FiMusic, FiMic, FiDisc, FiAlertTriangle } from 'react-icons/fi';
import { AdminTableSkeleton } from '../../components/common/Skeletons';

const AdminDashboard = ({ api }) => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const { data } = await api.get('/stats');
        setStats(data);
      } catch (err) {
        console.error("Failed to load stats");
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, [api]);

  const cards = [
    { label: 'Total Users', value: stats?.totalUsers, icon: FiUsers, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { label: 'Total Songs', value: stats?.totalSongs, icon: FiMusic, color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { label: 'Total Artists', value: stats?.totalArtists, icon: FiMic, color: 'text-pink-400', bg: 'bg-pink-400/10' },
    { label: 'Total Albums', value: stats?.totalAlbums, icon: FiDisc, color: 'text-green-400', bg: 'bg-green-400/10' },
    { label: 'Pending Reports', value: stats?.pendingReports, icon: FiAlertTriangle, color: 'text-red-400', bg: 'bg-red-400/10' },
  ];

  if (loading) return (
    <div className="space-y-8">
      <div className="h-8 w-64 bg-gray-800 rounded-lg animate-pulse mb-8" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {[1,2,3,4,5].map(i => <div key={i} className="h-32 bg-gray-900 border border-gray-800 rounded-2xl animate-pulse" />)}
      </div>
      <div className="mt-12">
        <AdminTableSkeleton cols={3} rows={5} />
      </div>
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-black mb-8 tracking-tight">System Overview</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {cards.map((card, idx) => (
          <div key={idx} className="bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-xl relative overflow-hidden group">
            <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full ${card.bg} blur-2xl group-hover:blur-3xl transition-all`}></div>
            <div className="flex items-center justify-between mb-4 relative z-10">
              <div className={`p-3 rounded-xl ${card.bg} ${card.color}`}>
                <card.icon size={24} />
              </div>
            </div>
            <h3 className="text-4xl font-black text-white relative z-10 mb-1">{card.value || 0}</h3>
            <p className="text-gray-400 font-medium text-sm relative z-10">{card.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-gray-900 border border-gray-800 rounded-2xl p-8">
        <h2 className="text-xl font-bold mb-4">Quick Actions</h2>
        <div className="flex gap-4">
          <button className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-3 rounded-xl font-semibold transition-all shadow-lg shadow-cyan-900/50">Add New Song</button>
          <button className="bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-xl font-semibold transition-all">Review Reports</button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
