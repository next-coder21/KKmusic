import React, { useEffect, useState } from 'react';
import { FiCheckCircle, FiXCircle } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { AdminTableSkeleton } from '../../components/common/Skeletons';

const AdminReports = ({ api }) => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchReports = async () => {
    try {
      const { data } = await api.get('/reports');
      setReports(data);
    } catch (err) {
      toast.error("Failed to load reports");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchReports(); }, [api]);

  const updateStatus = async (id, status) => {
    try {
      await api.patch(`/reports/${id}`, { status });
      setReports(reports.map(r => r.id === id ? { ...r, status } : r));
      toast.success(`Report marked as ${status}`);
    } catch (err) {
      toast.error("Update failed");
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-black tracking-tight">Content Reports</h1>
        <p className="text-gray-400 mt-1">Review user-submitted reports for inappropriate content.</p>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-950/50 text-gray-400 text-sm uppercase tracking-wider border-b border-gray-800">
                <th className="p-4 font-semibold">Type</th>
                <th className="p-4 font-semibold">Reason</th>
                <th className="p-4 font-semibold">Submitted By</th>
                <th className="p-4 font-semibold">Status</th>
                <th className="p-4 font-semibold text-right">Review Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                <tr><td colSpan="5"><AdminTableSkeleton cols={5} rows={10} /></td></tr>
              ) : reports.length === 0 ? (
                <tr><td colSpan="5" className="p-8 text-center text-gray-500">No content reports requiring attention. Good job!</td></tr>
              ) : (
                reports.map(report => (
                  <tr key={report.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="p-4">
                      <span className="font-bold text-white uppercase text-xs tracking-wider">{report.content_type}</span>
                      <p className="text-xs text-gray-500 font-mono mt-1 w-24 truncate" title={report.content_id}>{report.content_id}</p>
                    </td>
                    <td className="p-4">
                      <span className="text-red-400 font-bold capitalize">{report.reason}</span>
                      {report.notes && <p className="text-xs text-gray-400 italic mt-1 max-w-xs truncate">{report.notes}</p>}
                    </td>
                    <td className="p-4 text-gray-300 text-sm">{report.reporter_email}</td>
                    <td className="p-4">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-full border ${
                        report.status === 'pending' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' : 
                        report.status === 'dismissed' ? 'bg-gray-500/10 text-gray-400 border-gray-500/20' : 
                        'bg-green-500/10 text-green-400 border-green-500/20'
                      }`}>
                        {report.status}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      {report.status === 'pending' && (
                        <div className="flex items-center justify-end gap-2">
                          <button onClick={() => updateStatus(report.id, 'actioned')} className="p-2 text-green-500 hover:text-green-400 hover:bg-green-500/10 rounded-lg transition-colors font-bold" title="Actioned">
                            <FiCheckCircle />
                          </button>
                          <button onClick={() => updateStatus(report.id, 'dismissed')} className="p-2 text-gray-500 hover:text-red-400 hover:bg-gray-800 rounded-lg transition-colors font-bold" title="Dismiss">
                            <FiXCircle />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminReports;
