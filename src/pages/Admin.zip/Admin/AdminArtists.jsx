import React, { useEffect, useState } from 'react';
import { FiTrash2, FiPlus, FiUser } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { AdminTableSkeleton } from '../../components/common/Skeletons';

const AdminArtists = ({ api }) => {
  const [artists, setArtists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [newArtist, setNewArtist] = useState({ name: '', bio: '', image_url: '' });

  const fetchArtists = async () => {
    try {
      const { data } = await api.get('/artists');
      setArtists(data);
    } catch (err) {
      toast.error("Failed to load artists");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchArtists(); }, [api]);

  const handleDelete = async (id) => {
    if (!window.confirm("WARNING: Deleting an artist will also delete all their songs and albums. Proceed?")) return;
    try {
      await api.delete(`/artists/${id}`);
      setArtists(artists.filter(a => a.id !== id));
      toast.success("Artist deleted");
    } catch (err) {
      toast.error("Deletion failed");
    }
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    try {
      await api.post('/artists', newArtist);
      toast.success("Artist added successfully");
      setShowModal(false);
      fetchArtists();
    } catch (err) {
      toast.error("Failed to add artist");
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight">Manage Artists</h1>
          <p className="text-gray-400 mt-1">Add and manage application artists.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white px-5 py-2.5 rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-cyan-900/50">
          <FiPlus /> Add Artist
        </button>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-950/50 text-gray-400 text-sm uppercase tracking-wider border-b border-gray-800">
                <th className="p-4 font-semibold">Artist</th>
                <th className="p-4 font-semibold">Joined At</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                <tr><td colSpan="3"><AdminTableSkeleton cols={3} rows={8} /></td></tr>
              ) : artists.length === 0 ? (
                <tr><td colSpan="3" className="p-8 text-center text-gray-500">No artists found.</td></tr>
              ) : (
                artists.map(artist => (
                  <tr key={artist.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="p-4 flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-gray-800 flex-shrink-0 overflow-hidden border border-gray-700">
                        {artist.image_url ? (
                          <img src={artist.image_url} alt="artist" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center"><FiUser className="text-gray-500" /></div>
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-white text-lg">{artist.name}</p>
                        <p className="text-xs text-gray-500 max-w-xs truncate">{artist.bio || 'No bio available'}</p>
                      </div>
                    </td>
                    <td className="p-4 text-gray-400 text-sm">{new Date(artist.created_at).toLocaleDateString()}</td>
                    <td className="p-4 text-right">
                      <button onClick={() => handleDelete(artist.id)} className="p-2 text-gray-500 hover:text-red-400 hover:bg-gray-800 rounded-lg transition-colors" title="Delete">
                        <FiTrash2 />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">Add New Artist</h2>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Artist Name *</label>
                <input required type="text" value={newArtist.name} onChange={e=>setNewArtist({...newArtist, name: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="The Beatles" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Image URL</label>
                <input type="text" value={newArtist.image_url} onChange={e=>setNewArtist({...newArtist, image_url: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="https://..." />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Biography</label>
                <textarea rows="4" value={newArtist.bio} onChange={e=>setNewArtist({...newArtist, bio: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none resize-none" placeholder="A brief biography..."></textarea>
              </div>
              <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-gray-800">
                <button type="button" onClick={() => setShowModal(false)} className="px-5 py-2.5 text-gray-400 hover:text-white font-semibold">Cancel</button>
                <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-2.5 rounded-xl font-bold transition-colors">Save Artist</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminArtists;
