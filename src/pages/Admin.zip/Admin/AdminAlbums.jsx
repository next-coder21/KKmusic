import React, { useEffect, useState } from 'react';
import { FiTrash2, FiPlus, FiDisc } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { AdminTableSkeleton } from '../../components/common/Skeletons';

const AdminAlbums = ({ api }) => {
  const [albums, setAlbums] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [newAlbum, setNewAlbum] = useState({ title: '', artist_id: '', cover_url: '' });

  const fetchAlbums = async () => {
    try {
      const { data } = await api.get('/albums');
      setAlbums(data);
    } catch (err) {
      toast.error("Failed to load albums");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAlbums(); }, [api]);

  const handleDelete = async (id) => {
    if (!window.confirm("WARNING: Deleting an album deletes its songs too! Proceed?")) return;
    try {
      await api.delete(`/albums/${id}`);
      setAlbums(albums.filter(a => a.id !== id));
      toast.success("Album deleted");
    } catch (err) {
      toast.error("Deletion failed");
    }
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    try {
      await api.post('/albums', newAlbum);
      toast.success("Album added successfully");
      setShowModal(false);
      fetchAlbums();
    } catch (err) {
      toast.error("Failed to add album");
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight">Manage Albums</h1>
          <p className="text-gray-400 mt-1">Organize tracks into logical collections.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white px-5 py-2.5 rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-cyan-900/50">
          <FiPlus /> Add Album
        </button>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-950/50 text-gray-400 text-sm uppercase tracking-wider border-b border-gray-800">
                <th className="p-4 font-semibold">Album Title</th>
                <th className="p-4 font-semibold">Main Artist</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                <tr><td colSpan="3"><AdminTableSkeleton cols={3} rows={8} /></td></tr>
              ) : albums.length === 0 ? (
                <tr><td colSpan="3" className="p-8 text-center text-gray-500">No albums found.</td></tr>
              ) : (
                albums.map(album => (
                  <tr key={album.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="p-4 flex items-center gap-4">
                      <div className="w-12 h-12 rounded bg-gray-800 flex-shrink-0 overflow-hidden border border-gray-700">
                        <img src={album.cover_url || '/default-album.jpg'} alt="cover" className="w-full h-full object-cover" onError={e=>e.target.src='/default-album.jpg'} />
                      </div>
                      <p className="font-bold text-white text-lg">{album.title}</p>
                    </td>
                    <td className="p-4 text-gray-300 font-medium">{album.artist_name || 'Unknown'}</td>
                    <td className="p-4 text-right">
                      <button onClick={() => handleDelete(album.id)} className="p-2 text-gray-500 hover:text-red-400 hover:bg-gray-800 rounded-lg transition-colors" title="Delete">
                        <FiTrash2 />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-lg p-6 shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">Add New Album</h2>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Album Title *</label>
                <input required type="text" value={newAlbum.title} onChange={e=>setNewAlbum({...newAlbum, title: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="Abbey Road" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Cover Image URL</label>
                <input type="text" value={newAlbum.cover_url} onChange={e=>setNewAlbum({...newAlbum, cover_url: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="https://..." />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Artist UUID (Optional)</label>
                <input type="text" value={newAlbum.artist_id} onChange={e=>setNewAlbum({...newAlbum, artist_id: e.target.value})} className="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-cyan-500 outline-none" placeholder="uuid-..." />
              </div>
              <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-gray-800">
                <button type="button" onClick={() => setShowModal(false)} className="px-5 py-2.5 text-gray-400 hover:text-white font-semibold">Cancel</button>
                <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-2.5 rounded-xl font-bold transition-colors">Save Album</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminAlbums;
