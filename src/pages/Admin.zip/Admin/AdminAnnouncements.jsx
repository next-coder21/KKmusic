import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FiPlus, FiSearch, FiEdit2, FiEye, FiTrash2, FiSend, FiCheck,
  FiX, FiImage, FiUsers, FiShield, FiUser, FiCalendar, FiSettings,
  FiGift, FiMusic, FiChevronRight, FiAlertCircle, FiInfo, FiLayers, FiCopy,
  FiRadio, FiZap
} from 'react-icons/fi';
import toast from 'react-hot-toast';

/* ── Google Fonts ─────────────────────────────────────────── */
const FontLink = () => (
  <style>{`@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@700;800&display=swap');`}</style>
);

/* ── Type config ─────────────────────────────────────────── */
const TYPE_CONFIG = {
  system:      { icon: FiSettings,    label: 'System',      color: '#818cf8', bg: 'rgba(129,140,248,0.08)', border: 'rgba(129,140,248,0.25)' },
  promo:       { icon: FiGift,        label: 'Promo',       color: '#f59e0b', bg: 'rgba(245,158,11,0.08)',  border: 'rgba(245,158,11,0.25)' },
  new_release: { icon: FiMusic,       label: 'Release',     color: '#2dd4bf', bg: 'rgba(45,212,191,0.08)', border: 'rgba(45,212,191,0.25)' },
  event:       { icon: FiCalendar,    label: 'Event',       color: '#60a5fa', bg: 'rgba(96,165,250,0.08)', border: 'rgba(96,165,250,0.25)' },
  maintenance: { icon: FiAlertCircle, label: 'Maintenance', color: '#f87171', bg: 'rgba(248,113,113,0.08)', border: 'rgba(248,113,113,0.25)' },
};

const STATUS = {
  sent:      { dot: '#4ade80', label: 'TRANSMITTED', color: '#4ade80' },
  scheduled: { dot: '#f59e0b', label: 'QUEUED',      color: '#f59e0b' },
  draft:     { dot: '#52525b', label: 'DRAFT',        color: '#71717a' },
};

const getStatus = (ann) =>
  ann.sent_at ? 'sent' : ann.scheduled_at ? 'scheduled' : 'draft';

/* ── Thin horizontal label ───────────────────────────────── */
const SectionLabel = ({ icon: Icon, children, color = 'var(--accent)' }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
    <Icon size={12} style={{ color }} />
    <span style={{
      fontFamily: "'DM Mono', monospace",
      fontSize: 10,
      fontWeight: 500,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
    }}>{children}</span>
    <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
  </div>
);

/* ── Field wrapper ───────────────────────────────────────── */
const Field = ({ label, hint, children }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{
        fontFamily: "'DM Mono', monospace",
        fontSize: 9,
        fontWeight: 500,
        letterSpacing: '0.16em',
        textTransform: 'uppercase',
        color: 'var(--text-muted)',
      }}>{label}</span>
      {hint && <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: 'var(--text-muted)' }}>{hint}</span>}
    </div>
    {children}
  </div>
);

const inputStyle = {
  width: '100%',
  background: 'transparent',
  border: '1px solid var(--border)',
  borderRadius: 8,
  padding: '10px 14px',
  color: 'var(--text-primary)',
  fontSize: 13,
  outline: 'none',
  fontFamily: 'inherit',
  transition: 'border-color 0.15s',
};

/* ════════════════════════════════════════════════════════════
   Main Component
════════════════════════════════════════════════════════════ */
const AdminAnnouncements = ({ api }) => {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(null);
  const [viewMode, setViewMode] = useState('none');
  const [showConfirm, setShowConfirm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: '', body: '', type: 'system', target: 'all',
    target_emails: [], action_url: '', action_label: '',
    scheduled_at: '', send_immediately: true,
  });
  const [imagePreview, setImagePreview] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [emailInput, setEmailInput] = useState('');
  const fileInputRef = useRef(null);

  /* ── All original logic — untouched ───────────────────── */
  const fetchAnnouncements = async () => {
    setLoading(true);
    try {
      const status = filter === 'all' ? '' : filter;
      const { data } = await api.get(`/announcements?status=${status}`);
      setAnnouncements(data.announcements);
    } catch { toast.error('Failed to load announcements'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAnnouncements(); }, [filter, api]);

  const resetForm = () => {
    setFormData({ title: '', body: '', type: 'system', target: 'all', target_emails: [], action_url: '', action_label: '', scheduled_at: '', send_immediately: true });
    setImagePreview(null); setImageFile(null); setSelectedId(null);
  };

  const handleCreateNew = () => { resetForm(); setViewMode('compose'); };

  const handleEdit = (ann) => {
    if (ann.sent_at) { toast.error('Cannot edit a sent announcement'); return; }
    setFormData({ ...ann, send_immediately: !ann.scheduled_at, scheduled_at: ann.scheduled_at ? ann.scheduled_at.substring(0, 16) : '' });
    setImagePreview(ann.image_url); setSelectedId(ann.id); setViewMode('edit');
  };

  const compressImage = (file) => new Promise((resolve) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (e) => {
      const img = new Image();
      img.src = e.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const scale = 800 / img.width;
        canvas.width = 800; canvas.height = img.height * scale;
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        let q = 0.7, url = canvas.toDataURL('image/jpeg', q);
        if (url.length > 60000) url = canvas.toDataURL('image/jpeg', 0.5);
        resolve(url);
      };
    };
  });

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setIsSubmitting(true);
    try { setImagePreview(await compressImage(file)); setImageFile(null); }
    catch { toast.error('Compression failed'); }
    finally { setIsSubmitting(false); }
  };

  const handlePreview = (id) => {
    const ann = announcements.find(a => a.id === id);
    if (ann) { setFormData({ ...ann, send_immediately: !ann.scheduled_at, scheduled_at: ann.scheduled_at ? ann.scheduled_at.substring(0, 16) : '' }); setImagePreview(ann.image_url); }
    setSelectedId(id); setViewMode('preview');
  };

  const handleDuplicate = (ann) => {
    setFormData({ title: `${ann.title} (Copy)`, body: ann.body, type: ann.type, target: ann.target, target_emails: [...(ann.target_emails || [])], action_url: ann.action_url, action_label: ann.action_label, scheduled_at: '', send_immediately: true });
    setImagePreview(ann.image_url); setImageFile(null); setSelectedId(null); setViewMode('compose');
    toast.success('Copied to new draft');
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this announcement?')) return;
    try {
      await api.delete(`/announcements/${id}`);
      setAnnouncements(prev => prev.filter(a => a.id !== id));
      if (selectedId === id) setViewMode('none');
      toast.success('Deleted');
    } catch (err) { toast.error(err.response?.data?.error || 'Delete failed'); }
  };

  const handleAddEmail = (e) => {
    if (e.key !== 'Enter' && e.key !== ',') return;
    e.preventDefault();
    const email = emailInput.trim().replace(',', '');
    if (email && /^\S+@\S+\.\S+$/.test(email)) {
      if (!formData.target_emails.includes(email)) setFormData(p => ({ ...p, target_emails: [...p.target_emails, email] }));
      setEmailInput('');
    } else if (email) toast.error('Invalid email');
  };

  const removeEmail = (e) => setFormData(p => ({ ...p, target_emails: p.target_emails.filter(x => x !== e) }));

  const handleSave = async (isDraft = true) => {
    if (!formData.title.trim()) { toast.error('Title is required'); return; }
    setIsSubmitting(true);
    const fd = new FormData();
    Object.keys(formData).forEach(k => {
      if (k === 'target_emails') fd.append(k, JSON.stringify(formData[k]));
      else if (k === 'scheduled_at' && formData.send_immediately) fd.append(k, '');
      else fd.append(k, formData[k]);
    });
    if (imageFile) fd.append('image', imageFile);
    else if (imagePreview && typeof imagePreview === 'string') fd.append('image_url', imagePreview);
    try {
      if (viewMode === 'edit') { await api.put(`/announcements/${selectedId}`, fd); toast.success('Draft updated'); }
      else { const r = await api.post('/announcements', fd); setSelectedId(r.data.id); toast.success('Draft saved'); }
      fetchAnnouncements();
      if (!isDraft) setShowConfirm(true);
    } catch { toast.error('Failed to save'); }
    finally { setIsSubmitting(false); }
  };

  const handlePublish = async () => {
    if (!selectedId) { toast.error('No announcement selected'); return; }
    setIsSubmitting(true);
    try {
      const r = await api.post(`/announcements/${selectedId}/publish`);
      toast.success(`Transmitted to ${r.data.notified_count} users`);
      setShowConfirm(false); setViewMode('none'); fetchAnnouncements();
    } catch (err) { toast.error(err.response?.data?.error || 'Publish failed'); }
    finally { setIsSubmitting(false); }
  };

  const filtered = announcements.filter(a => a.title.toLowerCase().includes(search.toLowerCase()));

  /* ── Render ──────────────────────────────────────────── */
  return (
    <>
      <FontLink />
      <style>{`
        .ann-input:focus { border-color: var(--accent) !important; box-shadow: 0 0 0 3px var(--accent-soft); }
        .ann-scroll::-webkit-scrollbar { width: 3px; }
        .ann-scroll::-webkit-scrollbar-track { background: transparent; }
        .ann-scroll::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }
        .ann-card:hover { border-color: rgba(255,255,255,0.12) !important; }
        .ann-card.active { border-left-color: var(--accent) !important; }
      `}</style>

      <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 80px)', gap: 0 }}>

        {/* ── Page header ─────────────────────────────── */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
              <FiRadio size={16} style={{ color: 'var(--accent)' }} />
              <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: 'var(--text-muted)', letterSpacing: '0.18em', textTransform: 'uppercase' }}>
                Broadcast System
              </span>
            </div>
            <h1 style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, margin: 0, letterSpacing: '-0.03em' }}>
              Announcements
            </h1>
          </div>
          <motion.button
            whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
            onClick={handleCreateNew}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              background: 'var(--accent)', color: '#fff',
              padding: '10px 20px', borderRadius: 10,
              border: 'none', cursor: 'pointer',
              fontFamily: "'DM Mono', monospace",
              fontSize: 11, fontWeight: 500, letterSpacing: '0.08em',
              textTransform: 'uppercase',
            }}
          >
            <FiPlus size={14} /> New Broadcast
          </motion.button>
        </div>

        {/* ── Two-panel layout ─────────────────────────── */}
        <div style={{ display: 'flex', gap: 16, flex: 1, overflow: 'hidden' }}>

          {/* ══ LEFT — Feed ══════════════════════════════ */}
          <div style={{
            width: '38%', minWidth: 280,
            display: 'flex', flexDirection: 'column',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border)',
            borderRadius: 16, overflow: 'hidden',
          }}>
            {/* Search + filters */}
            <div style={{ padding: '14px 14px 10px', borderBottom: '1px solid var(--border)' }}>
              <div style={{ position: 'relative', marginBottom: 10 }}>
                <FiSearch size={12} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                <input
                  className="ann-input"
                  style={{ ...inputStyle, paddingLeft: 34, fontSize: 12, borderRadius: 8, background: 'var(--bg-primary)' }}
                  placeholder="Search..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {['all', 'draft', 'scheduled', 'sent'].map(f => (
                  <button key={f} onClick={() => setFilter(f)} style={{
                    padding: '4px 10px',
                    borderRadius: 6,
                    border: '1px solid',
                    borderColor: filter === f ? 'var(--accent)' : 'var(--border)',
                    background: filter === f ? 'var(--accent-soft)' : 'transparent',
                    color: filter === f ? 'var(--accent)' : 'var(--text-muted)',
                    fontFamily: "'DM Mono', monospace",
                    fontSize: 9, fontWeight: 500, letterSpacing: '0.1em',
                    textTransform: 'uppercase', cursor: 'pointer',
                    transition: 'all 0.15s',
                  }}>{f}</button>
                ))}
              </div>
            </div>

            {/* List */}
            <div className="ann-scroll" style={{ flex: 1, overflowY: 'auto', padding: '10px 10px' }}>
              {loading ? (
                [...Array(5)].map((_, i) => (
                  <div key={i} style={{
                    height: 76, borderRadius: 10, marginBottom: 6,
                    background: 'var(--bg-elevated)',
                    animation: 'pulse 1.5s ease-in-out infinite',
                    opacity: 0.5,
                  }} />
                ))
              ) : filtered.length === 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.35, textAlign: 'center', padding: 32 }}>
                  <FiLayers size={32} style={{ marginBottom: 12, color: 'var(--text-muted)' }} />
                  <p style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: 'var(--text-muted)', lineHeight: 1.6 }}>
                    No broadcasts found.<br />Try a different filter.
                  </p>
                </div>
              ) : (
                filtered.map((ann, i) => {
                  const status = getStatus(ann);
                  const tc = TYPE_CONFIG[ann.type] || TYPE_CONFIG.system;
                  const sc = STATUS[status];
                  const TypeIcon = tc.icon;
                  const isActive = selectedId === ann.id;

                  return (
                    <motion.div
                      key={ann.id}
                      className={`ann-card${isActive ? ' active' : ''}`}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.04 }}
                      onClick={() => ann.sent_at ? handlePreview(ann.id) : handleEdit(ann)}
                      style={{
                        display: 'flex', gap: 10, alignItems: 'flex-start',
                        padding: '10px 10px 10px 12px',
                        marginBottom: 5, borderRadius: 10,
                        border: '1px solid',
                        borderColor: isActive ? 'var(--accent)' : 'var(--border)',
                        borderLeft: `3px solid ${isActive ? 'var(--accent)' : sc.dot}`,
                        background: isActive ? 'var(--bg-elevated)' : 'var(--bg-primary)',
                        cursor: 'pointer', transition: 'all 0.15s',
                        position: 'relative',
                      }}
                    >
                      {/* Type icon */}
                      <div style={{
                        width: 32, height: 32, borderRadius: 8, flexShrink: 0,
                        background: tc.bg, border: `1px solid ${tc.border}`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: tc.color,
                        overflow: 'hidden',
                      }}>
                        {ann.image_url
                          ? <img src={ann.image_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          : <TypeIcon size={14} />}
                      </div>

                      {/* Content */}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 3 }}>
                          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: tc.color, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                            {tc.label}
                          </span>
                          <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--text-muted)', opacity: 0.4 }} />
                          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                            {ann.target === 'all' ? 'All' : ann.target === 'verified' ? 'Verified' : `${ann.target_emails?.length || 0} users`}
                          </span>
                        </div>
                        <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', lineHeight: 1.3 }}>
                          {ann.title}
                        </p>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 4 }}>
                          <span style={{ width: 5, height: 5, borderRadius: '50%', background: sc.dot, flexShrink: 0 }} />
                          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: sc.color, letterSpacing: '0.1em' }}>
                            {sc.label}
                            {ann.sent_at && ` · ${new Date(ann.sent_at).toLocaleDateString()}`}
                            {ann.scheduled_at && !ann.sent_at && ` · ${new Date(ann.scheduled_at).toLocaleDateString()}`}
                          </span>
                        </div>
                      </div>

                      {/* Actions on hover */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 3, flexShrink: 0 }}>
                        <button onClick={e => { e.stopPropagation(); handleDuplicate(ann); }}
                          style={{ padding: 4, background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', borderRadius: 5, display: 'flex' }}>
                          <FiCopy size={11} />
                        </button>
                        {!ann.sent_at && (
                          <button onClick={e => { e.stopPropagation(); handleDelete(ann.id); }}
                            style={{ padding: 4, background: 'transparent', border: 'none', cursor: 'pointer', color: '#f87171', borderRadius: 5, display: 'flex' }}>
                            <FiTrash2 size={11} />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>
          </div>

          {/* ══ RIGHT — Compose / Preview ════════════════ */}
          <div style={{
            flex: 1, display: 'none',
            background: 'var(--bg-secondary)',
            border: '1px solid var(--border)',
            borderRadius: 16, overflow: 'hidden',
            position: 'relative',
          }} className="md:!flex flex-col">

            <AnimatePresence mode="wait">

              {/* Empty state */}
              {viewMode === 'none' && (
                <motion.div key="none"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.3 }}>
                  <div style={{
                    width: 64, height: 64, borderRadius: '50%',
                    border: '2px dashed var(--text-muted)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    marginBottom: 16,
                  }}>
                    <FiRadio size={24} />
                  </div>
                  <p style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', margin: 0 }}>
                    Select or create a broadcast
                  </p>
                </motion.div>
              )}

              {/* Preview */}
              {viewMode === 'preview' && (
                <motion.div key="preview"
                  initial={{ x: 30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -20, opacity: 0 }}
                  style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                  <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <button onClick={() => setViewMode('none')}
                      style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--accent)', fontFamily: "'DM Mono', monospace", fontSize: 10, letterSpacing: '0.1em' }}>
                      <FiChevronRight style={{ transform: 'rotate(180deg)' }} size={12} /> BACK
                    </button>
                    <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: 'var(--text-muted)', letterSpacing: '0.18em', textTransform: 'uppercase' }}>
                      Live Preview
                    </span>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button onClick={() => handleDuplicate(announcements.find(a => a.id === selectedId))}
                        style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', border: '1px solid var(--border)', borderRadius: 7, background: 'transparent', color: 'var(--text-secondary)', cursor: 'pointer', fontFamily: "'DM Mono', monospace", fontSize: 10 }}>
                        <FiCopy size={11} /> Duplicate
                      </button>
                      {!announcements.find(a => a.id === selectedId)?.sent_at && (
                        <button onClick={() => setShowConfirm(true)}
                          style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', border: 'none', borderRadius: 7, background: 'var(--accent)', color: '#fff', cursor: 'pointer', fontFamily: "'DM Mono', monospace", fontSize: 10 }}>
                          <FiSend size={11} /> Send
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="ann-scroll" style={{ flex: 1, overflowY: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40, background: 'var(--bg-primary)' }}>
                    {/* Notification card mockup */}
                    <div style={{
                      width: '100%', maxWidth: 380,
                      background: 'var(--bg-secondary)',
                      border: '1px solid var(--border)',
                      borderRadius: 16, overflow: 'hidden',
                      boxShadow: '0 32px 64px rgba(0,0,0,0.4)',
                    }}>
                      {imagePreview && (
                        <div style={{ width: '100%', aspectRatio: '2/1', overflow: 'hidden' }}>
                          <img src={imagePreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        </div>
                      )}
                      <div style={{ padding: 20 }}>
                        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 14 }}>
                          {(() => {
                            const tc = TYPE_CONFIG[formData.type] || TYPE_CONFIG.system;
                            const TI = tc.icon;
                            return (
                              <div style={{ width: 36, height: 36, borderRadius: 9, background: tc.bg, border: `1px solid ${tc.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: tc.color, flexShrink: 0 }}>
                                <TI size={16} />
                              </div>
                            );
                          })()}
                          <div>
                            <p style={{ margin: 0, fontSize: 15, fontWeight: 700, color: 'var(--text-primary)', lineHeight: 1.3 }}>
                              {formData.title || 'Broadcast Title'}
                            </p>
                            <p style={{ margin: '3px 0 0', fontFamily: "'DM Mono', monospace", fontSize: 9, color: 'var(--text-muted)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                              KK Music Team
                            </p>
                          </div>
                        </div>
                        <p style={{ margin: '0 0 16px', fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.65, whiteSpace: 'pre-line' }}>
                          {formData.body || 'Your message content appears here...'}
                        </p>
                        {formData.action_url && (
                          <button style={{
                            width: '100%', padding: '11px', borderRadius: 9,
                            background: 'var(--accent)', color: '#fff', border: 'none',
                            fontFamily: "'DM Mono', monospace", fontSize: 11,
                            fontWeight: 500, letterSpacing: '0.08em', cursor: 'pointer',
                          }}>
                            {formData.action_label || 'ACTION'}
                          </button>
                        )}
                      </div>
                      <div style={{ padding: '10px 20px', borderTop: '1px solid var(--border)', background: 'var(--bg-elevated)' }}>
                        <p style={{ margin: 0, fontFamily: "'DM Mono', monospace", fontSize: 9, color: 'var(--text-muted)', letterSpacing: '0.1em', textAlign: 'center', textTransform: 'uppercase' }}>
                          TARGET: <span style={{ color: 'var(--accent)' }}>
                            {formData.target === 'all' ? 'ALL LISTENERS' : formData.target === 'verified' ? 'VERIFIED ONLY' : `${formData.target_emails.length} SPECIFIC`}
                          </span>
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Compose / Edit */}
              {(viewMode === 'compose' || viewMode === 'edit') && (
                <motion.div key="compose"
                  initial={{ x: 30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -20, opacity: 0 }}
                  style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

                  {/* Compose header */}
                  <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <FiZap size={13} style={{ color: 'var(--accent)' }} />
                      <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 15, fontWeight: 700 }}>
                        {viewMode === 'edit' ? 'Edit Broadcast' : 'New Broadcast'}
                      </span>
                    </div>
                    <button onClick={() => setViewMode('none')}
                      style={{ padding: 6, background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', borderRadius: 6, display: 'flex' }}>
                      <FiX size={16} />
                    </button>
                  </div>

                  {/* Form body */}
                  <div className="ann-scroll" style={{ flex: 1, overflowY: 'auto', padding: '24px 24px 100px' }}>

                    {/* Section 1: Content */}
                    <div style={{ marginBottom: 32 }}>
                      <SectionLabel icon={FiEdit2}>Content</SectionLabel>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

                        <Field label="Title *" hint={`${formData.title.length}/255`}>
                          <input
                            className="ann-input"
                            style={{ ...inputStyle, background: 'var(--bg-primary)', fontWeight: 600 }}
                            placeholder="What's the announcement?"
                            maxLength={255}
                            value={formData.title}
                            onChange={e => setFormData(p => ({ ...p, title: e.target.value }))}
                          />
                        </Field>

                        <Field label="Category">
                          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                            {Object.entries(TYPE_CONFIG).map(([key, cfg]) => {
                              const Icon = cfg.icon;
                              const active = formData.type === key;
                              return (
                                <motion.button
                                  key={key}
                                  whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                                  onClick={() => setFormData(p => ({ ...p, type: key }))}
                                  style={{
                                    display: 'flex', alignItems: 'center', gap: 6,
                                    padding: '6px 12px', borderRadius: 7,
                                    border: `1px solid ${active ? cfg.border : 'var(--border)'}`,
                                    background: active ? cfg.bg : 'transparent',
                                    color: active ? cfg.color : 'var(--text-muted)',
                                    cursor: 'pointer', transition: 'all 0.15s',
                                    fontFamily: "'DM Mono', monospace",
                                    fontSize: 10, fontWeight: 500, letterSpacing: '0.08em',
                                    textTransform: 'uppercase',
                                  }}
                                >
                                  <Icon size={11} /> {cfg.label}
                                </motion.button>
                              );
                            })}
                          </div>
                        </Field>

                        <Field label="Body">
                          <textarea
                            className="ann-input ann-scroll"
                            style={{ ...inputStyle, background: 'var(--bg-primary)', resize: 'none', lineHeight: 1.65 }}
                            rows={5}
                            placeholder="Describe your announcement..."
                            value={formData.body}
                            onChange={e => setFormData(p => ({ ...p, body: e.target.value }))}
                          />
                        </Field>
                      </div>
                    </div>

                    {/* Section 2: Banner */}
                    <div style={{ marginBottom: 32 }}>
                      <SectionLabel icon={FiImage} color="#60a5fa">Banner Image</SectionLabel>
                      <div
                        onClick={() => fileInputRef.current.click()}
                        style={{
                          border: `2px dashed ${imagePreview ? 'var(--accent)' : 'var(--border)'}`,
                          borderRadius: 12, padding: 24,
                          display: 'flex', flexDirection: 'column', alignItems: 'center',
                          cursor: 'pointer', transition: 'all 0.15s',
                          background: imagePreview ? 'var(--accent-soft)' : 'transparent',
                          position: 'relative',
                        }}
                      >
                        <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageChange} style={{ display: 'none' }} />
                        {imagePreview ? (
                          <div style={{ position: 'relative', width: '100%', maxWidth: 320 }}>
                            <img src={imagePreview} alt="" style={{ width: '100%', aspectRatio: '2/1', objectFit: 'cover', borderRadius: 8 }} />
                            <button
                              onClick={e => { e.stopPropagation(); setImagePreview(null); setImageFile(null); }}
                              style={{ position: 'absolute', top: -8, right: -8, width: 22, height: 22, borderRadius: '50%', background: '#ef4444', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
                              <FiX size={10} />
                            </button>
                          </div>
                        ) : (
                          <div style={{ textAlign: 'center' }}>
                            <FiImage size={28} style={{ color: 'var(--text-muted)', marginBottom: 10 }} />
                            <p style={{ margin: 0, fontFamily: "'DM Mono', monospace", fontSize: 10, color: 'var(--text-muted)', letterSpacing: '0.08em' }}>
                              CLICK TO UPLOAD · PNG / JPG / WEBP · MAX 2MB
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Section 3: CTA */}
                    <div style={{ marginBottom: 32 }}>
                      <SectionLabel icon={FiLink} color="#2dd4bf">Call to Action (Optional)</SectionLabel>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                        <Field label="Action URL">
                          <input
                            className="ann-input"
                            style={{ ...inputStyle, background: 'var(--bg-primary)', fontSize: 12 }}
                            placeholder="https://..."
                            value={formData.action_url}
                            onChange={e => setFormData(p => ({ ...p, action_url: e.target.value }))}
                          />
                        </Field>
                        <Field label="Button Label">
                          <input
                            className="ann-input"
                            style={{ ...inputStyle, background: 'var(--bg-primary)', fontSize: 12 }}
                            placeholder="Listen now"
                            value={formData.action_label}
                            onChange={e => setFormData(p => ({ ...p, action_label: e.target.value }))}
                          />
                        </Field>
                      </div>
                      {formData.action_url && (
                        <div style={{ marginTop: 8, padding: '8px 14px', borderRadius: 8, background: 'var(--accent-soft)', border: '1px solid var(--accent)', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: 'var(--accent)' }}>
                            BUTTON PREVIEW →
                          </span>
                          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: 'var(--text-secondary)' }}>
                            {formData.action_label || 'Action'}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Section 4: Targeting */}
                    <div style={{ marginBottom: 32 }}>
                      <SectionLabel icon={FiUsers} color="#4ade80">Audience</SectionLabel>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: 14 }}>
                        {[
                          { id: 'all', label: 'All Users', icon: FiUsers },
                          { id: 'verified', label: 'Verified', icon: FiShield },
                          { id: 'specific', label: 'Specific', icon: FiUser },
                        ].map(t => {
                          const active = formData.target === t.id;
                          return (
                            <motion.button key={t.id}
                              whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                              onClick={() => setFormData(p => ({ ...p, target: t.id }))}
                              style={{
                                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                                padding: '14px 10px', borderRadius: 10,
                                border: `1px solid ${active ? 'var(--accent)' : 'var(--border)'}`,
                                background: active ? 'var(--accent-soft)' : 'transparent',
                                cursor: 'pointer', transition: 'all 0.15s',
                              }}>
                              <t.icon size={18} style={{ color: active ? 'var(--accent)' : 'var(--text-muted)' }} />
                              <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: active ? 'var(--accent)' : 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                                {t.label}
                              </span>
                            </motion.button>
                          );
                        })}
                      </div>

                      {formData.target === 'specific' && (
                        <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}>
                          <Field label={`Recipient Emails · ${formData.target_emails.length} added`}>
                            <div style={{ background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, padding: 8, minHeight: 80, display: 'flex', flexWrap: 'wrap', gap: 5, alignContent: 'flex-start' }}>
                              {formData.target_emails.map(e => (
                                <span key={e} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'var(--accent-soft)', border: '1px solid var(--accent)', borderRadius: 5, padding: '3px 8px', fontFamily: "'DM Mono', monospace", fontSize: 10, color: 'var(--accent)' }}>
                                  {e} <FiX size={10} style={{ cursor: 'pointer' }} onClick={() => removeEmail(e)} />
                                </span>
                              ))}
                              <input
                                style={{ background: 'transparent', border: 'none', outline: 'none', fontSize: 12, color: 'var(--text-primary)', flex: 1, minWidth: 180, fontFamily: 'inherit' }}
                                placeholder="Type email and press Enter..."
                                value={emailInput}
                                onChange={e => setEmailInput(e.target.value)}
                                onKeyDown={handleAddEmail}
                              />
                            </div>
                          </Field>
                        </motion.div>
                      )}
                    </div>

                    {/* Section 5: Scheduling */}
                    <div style={{ marginBottom: 8 }}>
                      <SectionLabel icon={FiCalendar} color="#f59e0b">Scheduling</SectionLabel>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                        {[
                          { val: true, label: 'Send immediately' },
                          { val: false, label: 'Schedule for later' },
                        ].map(opt => {
                          const active = formData.send_immediately === opt.val;
                          return (
                            <button key={String(opt.val)}
                              onClick={() => setFormData(p => ({ ...p, send_immediately: opt.val }))}
                              style={{
                                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                padding: '10px 14px', borderRadius: 9,
                                border: `1px solid ${active ? 'var(--accent)' : 'var(--border)'}`,
                                background: active ? 'var(--accent-soft)' : 'transparent',
                                cursor: 'pointer', transition: 'all 0.15s',
                              }}>
                              <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: active ? 'var(--accent)' : 'var(--text-muted)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                                {opt.label}
                              </span>
                              {active && <FiCheck size={12} style={{ color: 'var(--accent)' }} />}
                            </button>
                          );
                        })}
                      </div>

                      {!formData.send_immediately && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} style={{ marginTop: 10 }}>
                          <input
                            type="datetime-local"
                            className="ann-input"
                            style={{ ...inputStyle, background: 'var(--bg-primary)', fontFamily: "'DM Mono', monospace", fontSize: 11 }}
                            value={formData.scheduled_at}
                            onChange={e => setFormData(p => ({ ...p, scheduled_at: e.target.value }))}
                            min={new Date(Date.now() + 5 * 60000).toISOString().substring(0, 16)}
                          />
                          {formData.scheduled_at && (
                            <p style={{ margin: '6px 0 0', fontFamily: "'DM Mono', monospace", fontSize: 9, color: '#f59e0b', letterSpacing: '0.08em' }}>
                              QUEUED FOR: {new Date(formData.scheduled_at).toLocaleString()}
                            </p>
                          )}
                        </motion.div>
                      )}
                    </div>
                  </div>

                  {/* Footer */}
                  <div style={{
                    position: 'absolute', bottom: 0, left: 0, right: 0,
                    padding: '14px 24px',
                    background: 'var(--bg-secondary)',
                    borderTop: '1px solid var(--border)',
                    display: 'flex', justifyContent: 'flex-end', gap: 8,
                    zIndex: 10,
                  }}>
                    <button onClick={() => handleSave(true)} disabled={isSubmitting}
                      style={{ padding: '9px 18px', borderRadius: 8, border: '1px solid var(--border)', background: 'transparent', color: 'var(--text-secondary)', cursor: 'pointer', fontFamily: "'DM Mono', monospace", fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                      {isSubmitting ? 'Saving...' : 'Save Draft'}
                    </button>
                    <button onClick={() => setViewMode('preview')}
                      style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '9px 18px', borderRadius: 8, border: '1px solid var(--border)', background: 'transparent', color: 'var(--text-primary)', cursor: 'pointer', fontFamily: "'DM Mono', monospace", fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                      <FiEye size={12} /> Preview
                    </button>
                    <motion.button
                      whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                      onClick={() => handleSave(false)} disabled={isSubmitting}
                      style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '9px 20px', borderRadius: 8, border: 'none', background: 'var(--accent)', color: '#fff', cursor: 'pointer', fontFamily: "'DM Mono', monospace", fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 600 }}>
                      {isSubmitting ? 'Processing...' : 'Ready to Transmit'} <FiSend size={11} />
                    </motion.button>
                  </div>
                </motion.div>
              )}

            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* ── Confirmation Modal ──────────────────────────── */}
      <AnimatePresence>
        {showConfirm && (
          <div style={{ position: 'fixed', inset: 0, zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowConfirm(false)}
              style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(6px)' }}
            />
            <motion.div
              initial={{ scale: 0.92, opacity: 0, y: 16 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.92, opacity: 0, y: 16 }}
              transition={{ type: 'spring', stiffness: 280, damping: 22 }}
              style={{
                position: 'relative', zIndex: 10,
                background: 'var(--bg-secondary)',
                border: '1px solid var(--border)',
                borderRadius: 18, padding: 32,
                width: '100%', maxWidth: 420,
                boxShadow: '0 40px 80px rgba(0,0,0,0.6)',
              }}>
              {/* Icon */}
              <div style={{ width: 52, height: 52, borderRadius: 13, background: 'var(--accent-soft)', border: '1px solid var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px', color: 'var(--accent)' }}>
                <FiSend size={22} />
              </div>

              <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 20, fontWeight: 800, textAlign: 'center', margin: '0 0 8px', letterSpacing: '-0.02em' }}>
                Confirm Transmission
              </h2>

              <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 20px', lineHeight: 1.6 }}>
                Sending <span style={{ color: 'var(--text-primary)', fontWeight: 600 }}>"{formData.title}"</span> to{' '}
                <span style={{ color: 'var(--accent)', fontFamily: "'DM Mono', monospace", fontSize: 11 }}>
                  {formData.target === 'all' ? 'ALL ACTIVE USERS' : formData.target === 'verified' ? 'VERIFIED FANS' : `${formData.target_emails.length} USERS`}
                </span>.
                This cannot be undone.
              </p>

              {/* Summary row */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 24 }}>
                {[
                  ['Type', TYPE_CONFIG[formData.type]?.label || formData.type],
                  ['Target', formData.target],
                  ['Image', imagePreview ? 'Attached' : 'None'],
                  ['Send', formData.send_immediately ? 'Immediately' : 'Scheduled'],
                ].map(([k, v]) => (
                  <div key={k} style={{ padding: '8px 12px', borderRadius: 8, background: 'var(--bg-elevated)', border: '1px solid var(--border)' }}>
                    <p style={{ margin: 0, fontFamily: "'DM Mono', monospace", fontSize: 9, color: 'var(--text-muted)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 3 }}>{k}</p>
                    <p style={{ margin: 0, fontFamily: "'DM Mono', monospace", fontSize: 11, color: 'var(--text-primary)' }}>{v}</p>
                  </div>
                ))}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <button onClick={() => setShowConfirm(false)}
                  style={{ padding: '12px', borderRadius: 10, border: '1px solid var(--border)', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', fontFamily: "'DM Mono', monospace", fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                  Cancel
                </button>
                <motion.button
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={handlePublish} disabled={isSubmitting}
                  style={{ padding: '12px', borderRadius: 10, border: 'none', background: 'var(--accent)', color: '#fff', cursor: 'pointer', fontFamily: "'DM Mono', monospace", fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 600 }}>
                  {isSubmitting ? 'Transmitting...' : formData.send_immediately ? 'Transmit Now' : 'Queue It'}
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Hidden field label polyfill */}
      <style>{`
        @media (min-width: 768px) {
          .md\\:!flex { display: flex !important; }
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 0.25; }
        }
      `}</style>
    </>
  );
};

export default AdminAnnouncements;